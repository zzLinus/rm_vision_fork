#ifndef __SOCKET_INTERFACE__
#define __SOCKET_INTERFACE__

#include <arpa/inet.h>
#include <netdb.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <unistd.h>

#include <cstdio>
#include <cstring>
#include <iostream>
#include <map>
#include <memory>
#include <string>

#include "auto_aim_interfaces/msg/target.hpp"
#include "rm_serial_driver/packet.hpp"

namespace rm_serial_driver
{
template <typename T>
void unpack(T & t, void * ptr)
{
  for (size_t i = 0; i < sizeof(T); i++) {
    *((uint8_t *)&t + i) = *((uint8_t *)ptr + i);
  }
}

class Client_socket_interface
{
public:
  Client_socket_interface();
  ~Client_socket_interface();

  void socket_send(SendPacket & sp);
  void socket_receive(ReceivePacket & rp);

  inline void pack(SendPacket & sp);

private:
  int64_t port_num, sockfd;
  sockaddr_in serv_addr, cli_addr;
  struct hostent * server;
  char buffer[256];
  char buffer_w[256];
  char buffer_r[256];
  std::string host_name;

public:
private:
};
}  // namespace rm_serial_driver

#endif
