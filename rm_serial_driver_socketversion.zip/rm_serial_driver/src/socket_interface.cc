#include "rm_serial_driver/socket_interface.hpp"

#include <rclcpp/utilities.hpp>

#include "rm_serial_driver/crc.hpp"

namespace rm_serial_driver
{
void Client_socket_interface::socket_send(SendPacket & sp)
{
  bzero(buffer, 256);
  pack(sp);
  int n = sendto(
    sockfd, (const char *)buffer, sizeof(SendPacket), MSG_CONFIRM,
    (const struct sockaddr *)&serv_addr, sizeof(serv_addr));
  if (n > 0) {
    printf("1 write to server\n");
  }
}

inline void Client_socket_interface::pack(SendPacket & sp)
{
  for (size_t i = 0; i < sizeof(SendPacket); i++) {
    buffer[i] = *((uint8_t *)&sp + i);
  }
}

Client_socket_interface::Client_socket_interface()
: port_num(51718),
  // host_name("zzarch"),
  // host_name("192.168.123.110"),
  host_name("192.168.123.110")
{
  sockfd = socket(AF_INET, SOCK_DGRAM, 0);
  if (sockfd < 0) {
    printf("ERROR opening socket");
  }

  serv_addr.sin_family = AF_INET;
  serv_addr.sin_addr.s_addr = inet_addr("192.168.123.110");
  serv_addr.sin_port = htons(51718);
}

void Client_socket_interface::socket_receive(ReceivePacket & rp)
{
  bzero(buffer_r, 256);
  socklen_t len = sizeof(serv_addr);
  int n = recvfrom(sockfd, buffer_r, 256, MSG_WAITALL, (struct sockaddr *)&serv_addr, &len);

  if (n > 0) {
    for (size_t i = 0; i < sizeof(ReceivePacket); i++) {
      *((uint8_t *)&rp + i) = *((uint8_t *)buffer_r + i);
    }
    printf("client socket got message\n");
  }
}

Client_socket_interface::~Client_socket_interface() {}
}  // namespace rm_serial_driver
